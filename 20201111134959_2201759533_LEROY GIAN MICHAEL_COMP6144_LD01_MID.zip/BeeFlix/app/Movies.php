<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Movies extends Model
{

    protected $fillable = [
        'genre_id',
        'title',
        'photo',
        'Description',
        'rating',
    ];
    

    public function genre()
    {
        return $this->belongsTo(Genres::class, 'genre_id', 'id');
    }

    public function episodes()
    {
        return $this->hasMany(Episodes::class, 'movie_id', 'id');
    }
}
