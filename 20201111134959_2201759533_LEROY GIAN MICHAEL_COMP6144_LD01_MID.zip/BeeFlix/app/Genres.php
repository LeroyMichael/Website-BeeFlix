<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Genres extends Model
{

    protected $fillable = [
        'name',
    ];

    public function movies()
    {
        return $this->hasMany(Movies::class, 'genre_id', 'id');
    }
}
