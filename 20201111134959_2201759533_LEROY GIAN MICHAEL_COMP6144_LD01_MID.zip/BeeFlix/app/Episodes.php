<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Episodes extends Model
{
   
    protected $fillable = [
        'movie_id',
        'episodes',
        'title',
    ];
    

    public function movie()
    {
        return $this->belongsTo(Movies::class, 'genre_id', 'id');
    }
}
