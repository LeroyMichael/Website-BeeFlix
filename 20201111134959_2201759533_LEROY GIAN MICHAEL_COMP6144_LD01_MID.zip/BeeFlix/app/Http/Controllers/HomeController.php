<?php

namespace App\Http\Controllers;
use App\Genres;
use App\Movies;
use App\Episodes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{

    
    public function genre($id){
        $genres = Genres::find($id);
        $movies = Movies::all();
        return view('genre',['genres'=>$genres,'movies'=>$movies]);
    }

    public function moviedetail($id){
        $genres = Genres::all();
        $episodes = Episodes::where('movie_id','=',$id)->paginate(3);
        $movies = Movies::find($id);
        return view('detail',['episodes'=>$episodes,'movies'=>$movies,'genres'=>$genres]);
    }


    public function allmovie(){
        $movies = Movies::all();
        return view('allmovie',['movies'=>$movies]);
    }
    public function home(){
        $genres = Genres::all();
        $movies = Movies::all();
        $countDrama = Movies::where('genre_id','=','1')->count(); 
        $countKids = Movies::where('genre_id','=','2')->count(); 
        $countTvshow = Movies::where('genre_id','=','3')->count(); 
        return view('home',['genres'=>$genres, 'movies'=>$movies,'countDrama'=>$countDrama,'countKids'=>$countKids,'countTvshow'=>$countTvshow]);
    }

    public function movie(){
        $movies = Movies::all();
        return view('home',['movies'=>$movies]);
    }
}
