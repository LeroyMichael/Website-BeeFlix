<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EpisodesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('episodes')->insert([
            [
                'movie_id'=>1,
                'episode'=>'Episode 1',
                'title'=>'Engram Pattersky',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 2',
                'title'=>'The Curse of the Pirate Bride',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 3',
                'title'=>'Mario',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 4',
                'title'=>'Godparents',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 5',
                'title'=>'Lillypads',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 6',
                'title'=>'Tuesday Meeting',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 7',
                'title'=>'About Three Years Later',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 8',
                'title'=>'Where the Road Goes',
            ],
            [
                'movie_id'=>1,
                'episode'=>'Episode 9',
                'title'=>'San Diego',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 1',
                'title'=>'Openings',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 2',
                'title'=>'Exchanges',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 3',
                'title'=>'Double Pawns',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 4',
                'title'=>'Middle Game',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 5',
                'title'=>'Fork',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 6',
                'title'=>'Pitchfork',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 7',
                'title'=>'Spoon',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 8',
                'title'=>'Adjournment',
            ],
            [
                'movie_id'=>2,
                'episode'=>'Episode 9',
                'title'=>'End Game',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 1',
                'title'=>'Wartime',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 2',
                'title'=>'Civil Union',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 3',
                'title'=>'Kevin',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 4',
                'title'=>'Boss Fight',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 5',
                'title'=>'BFF',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 6',
                'title'=>'Pitchfork',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 7',
                'title'=>'InCase',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 8',
                'title'=>'All In',
            ],
            [
                'movie_id'=>3,
                'episode'=>'Episode 9',
                'title'=>'Reparations',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 1',
                'title'=>'Suzie, Do You Copy?',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 2',
                'title'=>'The Mall Rats',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 3',
                'title'=>'The sauna Test',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 4',
                'title'=>'The Flayed',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 5',
                'title'=>'The Bite',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 6',
                'title'=>'The Case',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 7',
                'title'=>'Mad Max',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 8',
                'title'=>'Will the Wise',
            ],
            [
                'movie_id'=>4,
                'episode'=>'Episode 9',
                'title'=>'The Pollywog',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 1',
                'title'=>'Engram Pattersky',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 2',
                'title'=>'The Curse of the Pirate Bride',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 3',
                'title'=>'Mario',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 4',
                'title'=>'Godparents',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 5',
                'title'=>'Lillypads',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 6',
                'title'=>'Tuesday Meeting',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 7',
                'title'=>'About Three Years Later',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 8',
                'title'=>'Where the Road Goes',
            ],
            [
                'movie_id'=>5,
                'episode'=>'Episode 9',
                'title'=>'San Diego',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 1',
                'title'=>'Openings',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 2',
                'title'=>'Exchanges',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 3',
                'title'=>'Double Pawns',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 4',
                'title'=>'Middle Game',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 5',
                'title'=>'Fork',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 6',
                'title'=>'Pitchfork',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 7',
                'title'=>'Spoon',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 8',
                'title'=>'Adjournment',
            ],
            [
                'movie_id'=>6,
                'episode'=>'Episode 9',
                'title'=>'End Game',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 1',
                'title'=>'Wartime',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 2',
                'title'=>'Civil Union',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 3',
                'title'=>'Kevin',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 4',
                'title'=>'Boss Fight',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 5',
                'title'=>'BFF',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 6',
                'title'=>'Pitchfork',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 7',
                'title'=>'InCase',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 8',
                'title'=>'All In',
            ],
            [
                'movie_id'=>7,
                'episode'=>'Episode 9',
                'title'=>'Reparations',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 1',
                'title'=>'Suzie, Do You Copy?',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 2',
                'title'=>'The Mall Rats',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 3',
                'title'=>'The sauna Test',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 4',
                'title'=>'The Flayed',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 5',
                'title'=>'The Bite',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 6',
                'title'=>'The Case',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 7',
                'title'=>'Mad Max',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 8',
                'title'=>'Will the Wise',
            ],
            [
                'movie_id'=>8,
                'episode'=>'Episode 9',
                'title'=>'The Pollywog',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 1',
                'title'=>'Engram Pattersky',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 2',
                'title'=>'The Curse of the Pirate Bride',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 3',
                'title'=>'Mario',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 4',
                'title'=>'Godparents',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 5',
                'title'=>'Lillypads',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 6',
                'title'=>'Tuesday Meeting',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 7',
                'title'=>'About Three Years Later',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 8',
                'title'=>'Where the Road Goes',
            ],
            [
                'movie_id'=>9,
                'episode'=>'Episode 9',
                'title'=>'San Diego',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 1',
                'title'=>'Openings',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 2',
                'title'=>'Exchanges',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 3',
                'title'=>'Double Pawns',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 4',
                'title'=>'Middle Game',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 5',
                'title'=>'Fork',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 6',
                'title'=>'Pitchfork',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 7',
                'title'=>'Spoon',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 8',
                'title'=>'Adjournment',
            ],
            [
                'movie_id'=>10,
                'episode'=>'Episode 9',
                'title'=>'End Game',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 1',
                'title'=>'Wartime',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 2',
                'title'=>'Civil Union',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 3',
                'title'=>'Kevin',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 4',
                'title'=>'Boss Fight',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 5',
                'title'=>'BFF',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 6',
                'title'=>'Pitchfork',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 7',
                'title'=>'InCase',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 8',
                'title'=>'All In',
            ],
            [
                'movie_id'=>11,
                'episode'=>'Episode 9',
                'title'=>'Reparations',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 1',
                'title'=>'Suzie, Do You Copy?',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 2',
                'title'=>'The Mall Rats',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 3',
                'title'=>'The sauna Test',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 4',
                'title'=>'The Flayed',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 5',
                'title'=>'The Bite',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 6',
                'title'=>'The Case',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 7',
                'title'=>'Mad Max',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 8',
                'title'=>'Will the Wise',
            ],
            [
                'movie_id'=>12,
                'episode'=>'Episode 9',
                'title'=>'The Pollywog',
            ],


        ]);
    }
}
