<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MoviesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('movies')->insert([
            [
                'genre_id' =>1,
                'title'=>'New Girl',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BMjA0MDc1NTk0Ml5BMl5BanBnXkFtZTgwMTk2ODA5NDM@._V1_UY268_CR16,0,182,268_AL_.jpg',
                'description'=>'After a bad break-up, Jess, an offbeat young woman, moves into an apartment loft with three single men. Although they find her behavior very unusual, the men support her - most of the time.',
                'rating'=>4,
            ],
            [
                'genre_id' =>1,
                'title'=>'The Queens Gambit',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BM2EwMmRhMmUtMzBmMS00ZDQ3LTg4OGEtNjlkODk3ZTMxMmJlXkEyXkFqcGdeQXVyMjM5ODk1NDU@._V1_UX182_CR0,0,182,268_AL_.jpg',
                'description'=>'Orphaned at 9, prodigious introvert Beth Harmon discovers and masters the game of chess in 1960s USA. But, child stardom comes at a price.',
                'rating'=>4,
            ],
            [
                'genre_id' =>1,
                'title'=>'Ozark',
                'photo'=>'https://i.pinimg.com/474x/b4/0d/b1/b40db15968b31830552c76203154fb83.jpg',
                'description'=>'Ozark is an American crime drama series created by Bill Dubuque and Mark Williams for Netflix and produced by Media Rights Capital. The series stars Jason Bateman and Laura Linney as a married couple who relocate their family to the Ozarks for money laundering.',
                'rating'=>3,
            ],
            [
                'genre_id' => 1,
                'title'=>'Suits',
                'photo'=>'https://i.pinimg.com/originals/6d/52/eb/6d52eb71bdabfe54652d84cee0aef106.jpg',
                'description'=>'On the run from a drug deal gone bad, brilliant college dropout Mike Ross, finds himself working with Harvey Specter, one of New York Citys best lawyers.',
                'rating'=>3,
            ],
            [

                'genre_id' => 2,
                'title'=>'Spongebob SquarePants',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BNTk2NzEyNTQtZTQ5MS00MjAyLTgzMDMtNDNkYTBkM2M2OTU3XkEyXkFqcGdeQXVyODUwNjEzMzg@._V1_UX182_CR0,0,182,268_AL_.jpg',
                'description'=>'The misadventures of a talking sea sponge who works at a fast food restaurant, attends a boating school, and lives in an underwater pineapple.',
                'rating'=>5,
            ],
            [
                'genre_id' => 2,
                'title'=>'We Bare Bears',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BYjQzOTA4N2YtYTlkMS00OTJlLWJiYTEtMDcxNWQ1NTNhYzYxXkEyXkFqcGdeQXVyNjM2NDIwMzQ@._V1_UY268_CR12,0,182,268_AL_.jpg',
                'description'=>'Three bear brothers do whatever they can to be a part of human society by doing what everyone around them does.',
                'rating'=>3,
            ],
            [
                'genre_id' => 2,
                'title'=>'Tayo the Little Bus',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BM2M3N2QyNjYtZTg4OS00ODkxLWJjOGYtMzlhZTdmMDkyNGJkXkEyXkFqcGdeQXVyNTM3MDMyMDQ@._V1_UY268_CR87,0,182,268_AL_.jpg',
                'description'=>'In a big city where various vehicles are happily living together, our little bus Tayo has just started learning his route in the city. There is lots more to learn for Tayo. Tayo and his friendly friends Rogi, Lani and Gani are helping each other to become great mature buses.',
                'rating'=>3,
            ],
            [
                'genre_id' => 2,
                'title'=>'Shaun the Sheep',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BNDExMGUxMjAtMTY0Mi00MDBiLTg3MGItOWY4ZTM3NGZjYTBjXkEyXkFqcGdeQXVyNzMwOTY2NTI@._V1_UY268_CR0,0,182,268_AL_.jpg',
                'description'=>'Shaun is a sheep who doesnt follow the flock - in fact, he leads them into all sorts of scrapes and scraps, turning peace in the valley into mayhem in the meadow. Shaun and his pals run rings around their poor sheepdog Bitzer, as he tries to stop the Farmer finding out whats going on behind his back. Every day brings a new adventure for Shaun.',
                'rating'=>3,
            ],
            [
                'genre_id' => 3,
                'title'=>'The Office',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BMDNkOTE4NDQtMTNmYi00MWE0LWE4ZTktYTc0NzhhNWIzNzJiXkEyXkFqcGdeQXVyMzQ2MDI5NjU@._V1_UX182_CR0,0,182,268_AL_.jpg',
                'description'=>'A mockumentary on a group of typical office workers, where the workday consists of ego clashes, inappropriate behavior, and tedium.',
                'rating'=>4,
            ],
            [
                'genre_id' => 3,
                'title'=>'Breaking Bad',
                'photo'=>'https://m.media-amazon.com/images/M/MV5BMjhiMzgxZTctNDc1Ni00OTIxLTlhMTYtZTA3ZWFkODRkNmE2XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg',
                'description'=>'Breaking Bad is an American neo-Western crime drama television series created and produced by Vince Gilligan. The show aired on AMC from January.',
                'rating'=>5,
            ],
            [
                'genre_id' => 3,
                'title'=>'Better Call Saul',
                'photo'=>'https://resizing.flixster.com/ZRX_Ra_32tTqo6fJjUrSHSLv46U=/206x305/v1.dDszMjk1ODI7ajsxODU4ODsxMjAwOzE2MDA7MjQwMA',
                'description'=>'Better Call Saul is an American television crime drama series created by Vince Gilligan and Peter Gould. It is both a spin-off and a prequel of Gilligans previous series, Breaking Bad.',
                'rating'=>4,
            ],
            [
                'genre_id' => 3,
                'title'=>'Stranger Things',
                'photo'=>'https://upload.wikimedia.org/wikipedia/en/f/f7/Stranger_Things_season_2.jpg',
                'description'=>'Stranger Things is an American science fiction horror streaming television series created by the Duffer Brothers and released on Netflix. The twins serve as showrunners and are executive producers along with Shawn Levy and Dan Cohen.',
                'rating'=>4,
            ],



        ]);
    }
}
