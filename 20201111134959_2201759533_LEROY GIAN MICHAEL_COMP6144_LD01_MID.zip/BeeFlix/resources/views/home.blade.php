@extends('master')
@section('content')
@foreach ($genres as $item)

<div class="home">
    
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="home__title mt-4"><b class="font-italic">{{$item->name}}</b></h3>
                @if($item->id==1)
                    <p class=".text-muted">{{$countDrama}} series</p>
                @elseif ($item->id==2)
                    <p class=".text-muted">{{$countKids}} series</p>    
                @else
                    <p class=".text-muted">{{$countTvshow}} series</p>   
                @endif
            </div>
        </div>
    </div>

    <div class="row mb-2">
        @php
            $i = 0
        @endphp
        @foreach ($movies as $movie)
            @if ($movie->genre_id==$item->id&&$i<2)
                @php
                    $i++
                @endphp
                <div class="col-md-6" >
                    
                    <div class="shadow p-3 mb-5 bg-white rounded row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative ">
                        <div class="col p-4 d-flex flex-column position-static my-auto">
                            <h3 class="d-flex justify-content-center align-self-center text-center">{{$movie->title}}</h3>
                            <div class="d-flex justify-content-center align-items-center">
                            <a class="btn btn-outline-primary " href="{{$movie->id}}">View {{$movie->title}}</a>
                            </div>
                        </div>
                        <div class="text-center">
                            <img src="{{$movie->photo}}" class="rounded mx-0 d-block" style="width: 182px; height:268px" alt="...">
                        </div>
                    </div>
                </div>
            @endif
        @endforeach
    </div>

</div>
  @endforeach

@endsection