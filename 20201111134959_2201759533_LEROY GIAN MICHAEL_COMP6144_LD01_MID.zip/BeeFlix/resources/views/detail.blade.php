@extends('master')
@section('content')

<div class="card mt-5 mb-5 shadow bg-white rounded">
    <div class="row no-gutters">
        <div class="col-md-4">
            <img src="{{$movies->photo}}" stye="width=200px; height=300px " class="card-img" alt="...">
        </div>
        <div class="col-md-8 p-3">
            <div class="card-body ">
                <h3 class="card-title">{{$movies->title}}</h3>
                <p class="card-text">{{$movies->description}}</p>
                @for ($i = 0; $i < 5; ++$i)
                    <i class="fa fa-star{{ $movies->rating<=$i?'-o':'' }}" aria-hidden="true"></i>
                @endfor
                @foreach ($genres as $item)
                    @if ($item->id==$movies->genre_id)
                        <p class="card-text"><small class="text-muted">Category: <a href="genre/{{$item->id}}">{{$item->name}}</a></small></p>
                    @endif
                @endforeach
                <table class="table">
                    <thead class="thead-dark">
                      <tr>
                        <th scope="col">Episode</th>
                        <th scope="col">Title</th>
                      </tr>
                    </thead>
                    <tbody>
                        @foreach ($episodes as $episode)
                            <tr>
                                <th scope="row">{{$episode->episode}}</th>
                                <td>{{$episode->title}}</td>
                            </tr>
                           
                        @endforeach
                    </tbody>
                </table>
                
                  {{$episodes->links()}}
            </div>
        </div>
    </div>
</div>

@endsection