
<?php $__env->startSection('content'); ?>

<div class="card mt-5 mb-5 shadow bg-white rounded">
    <div class="row no-gutters">
        <div class="col-md-4">
            <img src="<?php echo e($movies->photo); ?>" stye="width=200px; height=300px " class="card-img" alt="...">
        </div>
        <div class="col-md-8 p-3">
            <div class="card-body ">
                <h3 class="card-title"><?php echo e($movies->title); ?></h3>
                <p class="card-text"><?php echo e($movies->description); ?></p>
                <?php for($i = 0; $i < 5; ++$i): ?>
                    <i class="fa fa-star<?php echo e($movies->rating<=$i?'-o':''); ?>" aria-hidden="true"></i>
                <?php endfor; ?>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->id==$movies->genre_id): ?>
                        <p class="card-text"><small class="text-muted">Category: <a href="genre/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></small></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <table class="table">
                    <thead class="thead-dark">
                      <tr>
                        <th scope="col">Episode</th>
                        <th scope="col">Title</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($episode->episode); ?></th>
                                <td><?php echo e($episode->title); ?></td>
                            </tr>
                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                  <?php echo e($episodes->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\BeeFlix\resources\views/detail.blade.php ENDPATH**/ ?>