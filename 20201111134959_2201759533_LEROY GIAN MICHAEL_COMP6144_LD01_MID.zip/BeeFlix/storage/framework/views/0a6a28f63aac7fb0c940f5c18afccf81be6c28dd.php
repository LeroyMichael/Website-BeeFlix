
<?php $__env->startSection('content'); ?>

<div class="home">
    
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="home__title mt-4">
                    <b class="font-italic">
                        <?php echo e($genres->name); ?>

                    </b>
                </h3>
            </div>
        </div>
    </div>

    <div class="row mb-2">
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($movie->genre_id==$genres->id): ?>
                <div class="col-md-6">
                    
                    <div class="shadow p-3 mb-5 bg-white rounded row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative ">
                        <div class="col p-4 d-flex flex-column position-static my-auto">
                            <h3 class="d-flex justify-content-center align-self-center text-center"><?php echo e($movie->title); ?></h3>
                            <div class="d-flex justify-content-center align-items-center">
                            <a class="btn btn-outline-primary " href="/<?php echo e($movie->id); ?>">View <?php echo e($movie->title); ?></a>
                            </div>
                        </div>
                        <div class="text-center">
                            <img src="<?php echo e($movie->photo); ?>" class="rounded mx-0 d-block" style="width: 182px; height:268px" alt="...">
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\BeeFlix\resources\views/genre.blade.php ENDPATH**/ ?>